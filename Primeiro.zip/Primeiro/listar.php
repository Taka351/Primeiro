<?php
include "./database/ligacacao.php"

?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=
    , initial-scale=1.0">
    <title>Listar alunos</title>
</head>
<body>
<div>
    <h3>alunos</h3>
    <table>
        <tr>
            <th>Nome</th>
            <th>Data Nascimento</th>
            <th>Nr processo </th>
            <th>Nr telemovel</th>
            <th>email</th>
       <?php
       $query ="SELECT * from users order by nome";
       $sql = mysqli_query(mysql:$conn, query:$query);
       $leituras = mysqli_fetch_all( $sql, MYSQLI_ASSOC);  

       foreach ($leituras as $leitura) {
        ?>
        <tr>
            <td> <?=$leitura ['nome'] ?></td>
            <td> <?=$leitura ['dataNascimento'] ?></td>
            <td> <?=$leitura ['numeroProcesso'] ?></td>
            <td> <?=$leitura ['telefone'] ?></td>
            <td> <?=$leitura ['email'] ?></td>
        </tr>
       <?php 
       }
       ?>


        </tr>
    </table>
</div>
    

</body>
</html>